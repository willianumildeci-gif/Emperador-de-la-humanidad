# Operaciones básicas en Turbo Pascal 7.0

Programa de consola compatible con **Turbo Pascal 7.0** que muestra un saludo de Hola Mundo, solicita dos números y presenta su suma, resta, multiplicación y división.

## Archivo principal

- `OPERACIONES.PAS`: código fuente del programa.

## Compilación

1. Abre Turbo Pascal 7.0.
2. Selecciona **File > Open** y abre `OPERACIONES.PAS`.
3. Compila con **Compile > Compile** o presiona `Alt+F9`.
4. Ejecuta con **Run > Run** o presiona `Ctrl+F9`.

El programa controla el caso en que el segundo número sea cero y evita realizar una división inválida.
